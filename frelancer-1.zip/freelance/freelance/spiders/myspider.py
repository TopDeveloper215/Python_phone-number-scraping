

import scrapy
from selenium import webdriver
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from urllib.parse import urljoin
import csv

class MySpider(scrapy.Spider):
    name = 'my_spider'

    def start_requests(self):
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/94.0.4606.71 Safari/537.36'
        }
        
        yield scrapy.Request(url='https://www.storia.ro/ro/rezultate/vanzare/apartament/toata-romania?market=ALL&ownerTypeSingleSelect=ALL&by=DEFAULT&direction=DESC&viewType=listing', headers=headers, callback=self.parse)

    def parse(self, response):
        apartments = response.xpath(".//li[@data-cy='listing-item']/a/@href").extract()

        

        data = []

        with webdriver.Chrome(service=Service(executable_path='./chromedriver.exe')) as driver:
            for url in apartments:
                full_url = urljoin(response.url, url)
                driver.get(full_url)

                button = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.XPATH, '//button[@data-cy="phone-number.show-full-number-button"]'))
                )
                button.click()

                full_content = WebDriverWait(driver, 10).until(
                    EC.presence_of_element_located((By.XPATH, '//a[@data-cy="phone-number.full-phone-number"]'))
                ).text

                data.append({'Number': full_content})

        # Write to CSV
        with open('output.csv', 'w', newline='') as csvfile:
            fieldnames = ['Number']
            writer = csv.DictWriter(csvfile, fieldnames=fieldnames)
            writer.writeheader()
            for item in data:
                writer.writerow(item)



